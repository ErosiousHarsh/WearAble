package com.zc.wearablealpha

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Fragment : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_rel)
    }
}
